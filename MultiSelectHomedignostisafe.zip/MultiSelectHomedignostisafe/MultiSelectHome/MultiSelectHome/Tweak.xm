// ============================================================================
// MultiSelectHome - iOS 16 Rootless arm64e (PAC-Safe)
// Target: iPhone 14 Pro Max (A16 Bionic), iOS 16.1.1 Dopamine
// Version: 1.1.0 - Neon Animated Border (Zero-Block PAC Edition)
// ============================================================================

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/message.h>

@interface SBHIconModel : NSObject
- (NSArray *)allApplicationIcons;
- (NSDictionary *)leafIconsByIdentifier;
- (NSArray *)allIcons;
@end

@interface SBIconView : UIView
- (id)icon;
- (BOOL)isEditing;
- (void)tapGestureDidChange:(id)gesture;
- (void)setNeedsLayout;
- (void)layoutIfNeeded;
@end

@interface SBHIconManager : NSObject
@property(nonatomic, readonly, getter=isEditing) BOOL editing;
- (id)iconModel;
- (id)model;
- (id)rootFolder;
- (void)setEditing:(BOOL)editing withFeedbackBehavior:(id)feedbackBehavior;
- (void)uninstallIcon:(id)icon animate:(BOOL)animate completion:(id)completion;
- (void)removeIcon:(id)icon options:(NSUInteger)options completion:(id)completion;
- (UIViewController *)rootViewController;
- (void)iconViewWasTapped:(id)iconView;
- (void)iconViewWasTapped:(id)iconView modifierFlags:(long long)flags;
- (void)ms_handleSelectAll:(UIButton *)sender;
- (void)ms_handleDelete:(UIButton *)sender;
- (void)ms_handleDone:(UIButton *)sender;
- (void)ms_processUninstallTimer:(NSTimer *)timer;
@end

static SBHIconManager *gIconManager = nil;
static NSMutableSet *gSelectedIcons = nil;
static BOOL gSelectionMode = NO;
static UIVisualEffectView *gToolbar = nil;
static UILabel *gCountLabel = nil;
static UIButton *gAllButton = nil;
static UIButton *gDeleteButton = nil;
static NSMutableArray *gUninstallQueue = nil;
static NSTimer *gUninstallTimer = nil;
static NSInteger const kMSBorderTag = 98982;
static NSTimeInterval gLastToggleTime = 0;
static id gLastToggledIcon = nil;

static inline NSString *MSRuntimeString(const char *value) {
    return [NSString stringWithUTF8String:value];
}

// Forward declarations
static void MSRefreshToolbarUI(void);
static void MSHideToolbarAndClear(void);
static void MSSetIconViewBorder(UIView *iconView, BOOL selected);
static void MSToggleIconSelection(id icon, UIView *iconView);
static void MSRefreshAllVisibleBadges(void);
static NSString *MSBundleIdentifierForIcon(id icon);
static BOOL MSIsDeletableIcon(id icon);
static NSArray *MSGetAllApplicationIcons(SBHIconManager *manager);
static void MSProcessNextUninstall(void);
static void MSStartBatchUninstall(NSArray *icons);
static void MSShowActionToolbar(void);

// ----------------------------------------------------------------------------
// GPU-Accelerated Neon Border Helper (Green -> Purple -> Blue Animation)
// ----------------------------------------------------------------------------
static void MSSetIconViewBorder(UIView *iconView, BOOL selected) {
    if (!iconView || ![iconView isKindOfClass:[UIView class]]) return;
    UIView *borderView = [iconView viewWithTag:kMSBorderTag];

    if (selected) {
        if (!borderView) {
            CGFloat iconWidth = iconView.bounds.size.width;
            if (iconWidth < 30.0) iconWidth = 60.0;
            CGRect frame = CGRectMake(-3, -3, iconWidth + 6, iconWidth + 6);
            CGFloat radius = 17.5;

            borderView = [[UIView alloc] initWithFrame:frame];
            borderView.tag = kMSBorderTag;
            borderView.userInteractionEnabled = NO;
            borderView.clipsToBounds = YES;
            borderView.layer.cornerRadius = radius;

            // 1. Animated Gradient Layer (Green, Purple, Blue, Green)
            CAGradientLayer *gradient = [CAGradientLayer layer];
            gradient.frame = borderView.bounds;
            gradient.startPoint = CGPointMake(0, 0);
            gradient.endPoint = CGPointMake(1, 1);

            id cGreen  = (id)[UIColor colorWithRed:0.18 green:0.86 blue:0.45 alpha:1.0].CGColor;
            id cPurple = (id)[UIColor colorWithRed:0.68 green:0.25 blue:0.98 alpha:1.0].CGColor;
            id cBlue   = (id)[UIColor colorWithRed:0.22 green:0.58 blue:0.98 alpha:1.0].CGColor;

            gradient.colors = @[cGreen, cPurple, cBlue, cGreen];

            // 2. Shape Layer Stroke Mask
            CAShapeLayer *maskLayer = [CAShapeLayer layer];
            maskLayer.frame = borderView.bounds;
            UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(borderView.bounds, 1.6, 1.6)
                                                           cornerRadius:radius - 1.6];
            maskLayer.path = path.CGPath;
            maskLayer.lineWidth = 3.2;
            maskLayer.strokeColor = [UIColor whiteColor].CGColor;
            maskLayer.fillColor = [UIColor clearColor].CGColor;
            gradient.mask = maskLayer;

            // 3. Smooth continuous color shift animation (Zero Blocks)
            CABasicAnimation *shiftAnim = [CABasicAnimation animationWithKeyPath:MSRuntimeString("colors")];
            shiftAnim.fromValue = @[cGreen, cPurple, cBlue, cGreen];
            shiftAnim.toValue = @[cPurple, cBlue, cGreen, cPurple];
            shiftAnim.duration = 2.2;
            shiftAnim.repeatCount = HUGE_VALF;
            shiftAnim.autoreverses = YES;
            shiftAnim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
            [gradient addAnimation:shiftAnim forKey:MSRuntimeString("neonBorderShift")];

            [borderView.layer addSublayer:gradient];
            [iconView addSubview:borderView];
        }
        borderView.hidden = NO;
        [iconView bringSubviewToFront:borderView];
        iconView.alpha = 0.95;
    } else {
        if (borderView) {
            borderView.hidden = YES;
        }
        iconView.alpha = 1.0;
    }
}

static void MSToggleIconSelection(id icon, UIView *iconView) {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (gLastToggledIcon == icon && (now - gLastToggleTime) < 0.25) {
        return;
    }
    gLastToggledIcon = icon;
    gLastToggleTime = now;

    if (!gSelectedIcons) gSelectedIcons = [NSMutableSet new];
    if ([gSelectedIcons containsObject:icon]) {
        [gSelectedIcons removeObject:icon];
        MSSetIconViewBorder(iconView, NO);
    } else {
        [gSelectedIcons addObject:icon];
        MSSetIconViewBorder(iconView, YES);
    }
    MSRefreshToolbarUI();
}

static NSString *MSBundleIdentifierForIcon(id icon) {
    if (!icon) return nil;
    const char *selectors[] = {
        "applicationBundleIdentifier",
        "applicationBundleID",
        "bundleIdentifier",
        "leafIdentifier",
        "nodeIdentifier",
        NULL
    };
    for (int i = 0; selectors[i] != NULL; i++) {
        SEL s = sel_registerName(selectors[i]);
        if ([icon respondsToSelector:s]) {
            id bid = ((id (*)(id, SEL))objc_msgSend)(icon, s);
            if ([bid isKindOfClass:[NSString class]] && [(NSString *)bid length] > 0) {
                return (NSString *)bid;
            }
        }
    }

    SEL appSel = sel_registerName("application");
    if ([icon respondsToSelector:appSel]) {
        id app = ((id (*)(id, SEL))objc_msgSend)(icon, appSel);
        if (app && [app respondsToSelector:sel_registerName("bundleIdentifier")]) {
            id bid = ((id (*)(id, SEL))objc_msgSend)(app, sel_registerName("bundleIdentifier"));
            if ([bid isKindOfClass:[NSString class]] && [(NSString *)bid length] > 0) {
                return (NSString *)bid;
            }
        }
    }
    return nil;
}

static BOOL MSIsDeletableIcon(id icon) {
    if (!icon) return NO;
    NSString *bundleID = MSBundleIdentifierForIcon(icon);

    if (bundleID && [bundleID hasPrefix:MSRuntimeString("com.apple.")]) {
        const char *protectedPrefixes[] = {
            "com.apple.Preferences",
            "com.apple.mobilephone",
            "com.apple.camera",
            "com.apple.AppStore",
            "com.apple.MobileStore",
            "com.apple.springboard",
            "com.apple.InCallService",
            "com.apple.compass",
            NULL
        };
        for (int i = 0; protectedPrefixes[i] != NULL; i++) {
            if ([bundleID isEqualToString:MSRuntimeString(protectedPrefixes[i])]) {
                return NO;
            }
        }
    }

    SEL uninstallSel = sel_registerName("isUninstallSupported");
    if ([icon respondsToSelector:uninstallSel]) {
        return ((BOOL (*)(id, SEL))objc_msgSend)(icon, uninstallSel);
    }
    SEL isDeletableSel = sel_registerName("isDeletable");
    if ([icon respondsToSelector:isDeletableSel]) {
        return ((BOOL (*)(id, SEL))objc_msgSend)(icon, isDeletableSel);
    }

    if (bundleID && bundleID.length > 0) {
        return YES;
    }
    return NO;
}

static void MSRefreshAllVisibleBadges(void) {
    if (!gIconManager) return;
    UIViewController *rootVC = nil;
    SEL rootVCSel = sel_registerName("rootViewController");
    if ([gIconManager respondsToSelector:rootVCSel]) {
        rootVC = ((id (*)(id, SEL))objc_msgSend)(gIconManager, rootVCSel);
    }
    if (!rootVC || !rootVC.view) return;

    NSMutableArray *viewsToVisit = [NSMutableArray arrayWithObject:rootVC.view];
    Class iconViewClass = objc_getClass("SBIconView");
    while (viewsToVisit.count > 0) {
        UIView *v = viewsToVisit.firstObject;
        [viewsToVisit removeObjectAtIndex:0];
        if (iconViewClass && [v isKindOfClass:iconViewClass]) {
            [v setNeedsLayout];
            [v layoutIfNeeded];
        } else if (v.subviews.count > 0) {
            [viewsToVisit addObjectsFromArray:v.subviews];
        }
    }
}

static void MSRefreshToolbarUI(void) {
    if (!gToolbar || !gCountLabel) return;
    NSUInteger count = gSelectedIcons.count;
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "%lu selected", (unsigned long)count);
    gCountLabel.text = MSRuntimeString(buffer);

    if (gAllButton) {
        [gAllButton setTitle:MSRuntimeString(count > 0 ? "Deselect" : "Select All") forState:UIControlStateNormal];
    }

    if (gDeleteButton) {
        gDeleteButton.enabled = (count > 0);
        gDeleteButton.alpha = (count > 0) ? 1.0 : 0.4;
    }

    MSRefreshAllVisibleBadges();
}

static void MSHideToolbarAndClear(void) {
    gSelectionMode = NO;
    if (gUninstallTimer) {
        [gUninstallTimer invalidate];
        gUninstallTimer = nil;
    }
    gUninstallQueue = nil;
    [gSelectedIcons removeAllObjects];
    MSRefreshAllVisibleBadges();
    [gToolbar removeFromSuperview];
    gToolbar = nil;
    gCountLabel = nil;
    gAllButton = nil;
    gDeleteButton = nil;
}

static NSArray *MSGetAllApplicationIcons(SBHIconManager *manager) {
    SBHIconManager *mgr = manager ? manager : gIconManager;
    if (!mgr) return @[];

    id model = nil;
    SEL iconModelSel = sel_registerName("iconModel");
    SEL modelSel = sel_registerName("model");
    if ([mgr respondsToSelector:iconModelSel]) {
        model = ((id (*)(id, SEL))objc_msgSend)(mgr, iconModelSel);
    } else if ([mgr respondsToSelector:modelSel]) {
        model = ((id (*)(id, SEL))objc_msgSend)(mgr, modelSel);
    }

    id rootFolder = nil;
    SEL rootFolderSel = sel_registerName("rootFolder");
    if ([mgr respondsToSelector:rootFolderSel]) {
        rootFolder = ((id (*)(id, SEL))objc_msgSend)(mgr, rootFolderSel);
        if (!model && rootFolder && [rootFolder respondsToSelector:modelSel]) {
            model = ((id (*)(id, SEL))objc_msgSend)(rootFolder, modelSel);
        }
    }

    if (!model) {
        Class iconControllerClass = objc_getClass("SBIconController");
        if (iconControllerClass) {
            SEL sharedSel = sel_registerName("sharedInstance");
            if ([iconControllerClass respondsToSelector:sharedSel]) {
                id controller = ((id (*)(id, SEL))objc_msgSend)(iconControllerClass, sharedSel);
                if (controller) {
                    if ([controller respondsToSelector:modelSel]) {
                        model = ((id (*)(id, SEL))objc_msgSend)(controller, modelSel);
                    } else if ([controller respondsToSelector:iconModelSel]) {
                        model = ((id (*)(id, SEL))objc_msgSend)(controller, iconModelSel);
                    }
                }
            }
        }
    }

    if (model) {
        SEL allAppsSel = sel_registerName("allApplicationIcons");
        if ([model respondsToSelector:allAppsSel]) {
            id apps = ((id (*)(id, SEL))objc_msgSend)(model, allAppsSel);
            if ([apps isKindOfClass:[NSArray class]] && [(NSArray *)apps count] > 0) {
                return (NSArray *)apps;
            }
        }
        SEL leafSel = sel_registerName("leafIconsByIdentifier");
        if ([model respondsToSelector:leafSel]) {
            id dict = ((id (*)(id, SEL))objc_msgSend)(model, leafSel);
            if ([dict isKindOfClass:[NSDictionary class]] && [(NSDictionary *)dict count] > 0) {
                return [(NSDictionary *)dict allValues];
            }
        }
        SEL allIconsSel = sel_registerName("allIcons");
        if ([model respondsToSelector:allIconsSel]) {
            id icons = ((id (*)(id, SEL))objc_msgSend)(model, allIconsSel);
            if ([icons isKindOfClass:[NSArray class]] && [(NSArray *)icons count] > 0) {
                return (NSArray *)icons;
            }
        }
    }

    if (rootFolder) {
        SEL allIconsSel = sel_registerName("allIcons");
        if ([rootFolder respondsToSelector:allIconsSel]) {
            id icons = ((id (*)(id, SEL))objc_msgSend)(rootFolder, allIconsSel);
            if ([icons isKindOfClass:[NSArray class]] && [(NSArray *)icons count] > 0) {
                return (NSArray *)icons;
            }
        }
    }

    return @[];
}

static void MSProcessNextUninstall(void) {
    if (!gUninstallQueue || gUninstallQueue.count == 0) {
        if (gUninstallTimer) {
            [gUninstallTimer invalidate];
            gUninstallTimer = nil;
        }
        gUninstallQueue = nil;
        MSHideToolbarAndClear();
        if (gIconManager) {
            SEL setEditingSel = sel_registerName("setEditing:withFeedbackBehavior:");
            if ([gIconManager respondsToSelector:setEditingSel]) {
                ((void (*)(id, SEL, BOOL, id))objc_msgSend)(gIconManager, setEditingSel, NO, nil);
            }
        }
        return;
    }

    id icon = gUninstallQueue.firstObject;
    [gUninstallQueue removeObjectAtIndex:0];

    if (gIconManager && icon) {
        SEL uninstallSel = sel_registerName("uninstallIcon:animate:completion:");
        SEL removeSel = sel_registerName("removeIcon:options:completion:");
        if ([gIconManager respondsToSelector:uninstallSel]) {
            ((void (*)(id, SEL, id, BOOL, id))objc_msgSend)(gIconManager, uninstallSel, icon, YES, nil);
        } else if ([gIconManager respondsToSelector:removeSel]) {
            ((void (*)(id, SEL, id, NSUInteger, id))objc_msgSend)(gIconManager, removeSel, icon, 0, nil);
        }
    }
}

static void MSStartBatchUninstall(NSArray *icons) {
    if (!icons || icons.count == 0) return;
    gUninstallQueue = [icons mutableCopy];
    MSProcessNextUninstall();
    if (gUninstallQueue.count > 0 && gIconManager) {
        gUninstallTimer = [NSTimer scheduledTimerWithTimeInterval:0.8
                                                           target:gIconManager
                                                         selector:@selector(ms_processUninstallTimer:)
                                                         userInfo:nil
                                                          repeats:YES];
    }
}

// Zero-block, synchronous toolbar presentation
static void MSShowActionToolbar(void) {
    if (gToolbar || !gIconManager || ![gIconManager respondsToSelector:@selector(rootViewController)]) {
        return;
    }

    UIViewController *rootVC = [gIconManager rootViewController];
    UIView *hostView = rootVC.view;
    if (!hostView) return;

    gToolbar = [[UIVisualEffectView alloc] initWithEffect:
                [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark]];
    gToolbar.layer.cornerRadius = 20;
    gToolbar.clipsToBounds = YES;
    gToolbar.layer.borderWidth = 0.5;
    gToolbar.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
    gToolbar.translatesAutoresizingMaskIntoConstraints = NO;
    [hostView addSubview:gToolbar];

    [NSLayoutConstraint activateConstraints:@[
        [gToolbar.leadingAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.leadingAnchor constant:12],
        [gToolbar.trailingAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.trailingAnchor constant:-12],
        [gToolbar.bottomAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.bottomAnchor constant:-8],
        [gToolbar.heightAnchor constraintEqualToConstant:56],
    ]];

    gCountLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    gCountLabel.text = MSRuntimeString("0 selected");
    gCountLabel.textColor = UIColor.whiteColor;
    gCountLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    gCountLabel.textAlignment = NSTextAlignmentCenter;

    gAllButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [gAllButton setTitle:MSRuntimeString("Select All") forState:UIControlStateNormal];
    [gAllButton setTitleColor:[UIColor colorWithWhite:0.95 alpha:1.0] forState:UIControlStateNormal];
    gAllButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [gAllButton addTarget:gIconManager action:@selector(ms_handleSelectAll:) forControlEvents:UIControlEventTouchUpInside];

    gDeleteButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [gDeleteButton setTitle:MSRuntimeString("Delete") forState:UIControlStateNormal];
    [gDeleteButton setTitleColor:UIColor.systemRedColor forState:UIControlStateNormal];
    gDeleteButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    gDeleteButton.enabled = NO;
    gDeleteButton.alpha = 0.4;
    [gDeleteButton addTarget:gIconManager action:@selector(ms_handleDelete:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *doneButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [doneButton setTitle:MSRuntimeString("Done") forState:UIControlStateNormal];
    [doneButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    doneButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [doneButton addTarget:gIconManager action:@selector(ms_handleDone:) forControlEvents:UIControlEventTouchUpInside];

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[
        gCountLabel, gAllButton, gDeleteButton, doneButton
    ]];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.distribution = UIStackViewDistributionFillEqually;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [gToolbar.contentView addSubview:stack];

    [NSLayoutConstraint activateConstraints:@[
        [stack.leadingAnchor constraintEqualToAnchor:gToolbar.contentView.leadingAnchor constant:12],
        [stack.trailingAnchor constraintEqualToAnchor:gToolbar.contentView.trailingAnchor constant:-12],
        [stack.topAnchor constraintEqualToAnchor:gToolbar.contentView.topAnchor constant:4],
        [stack.bottomAnchor constraintEqualToAnchor:gToolbar.contentView.bottomAnchor constant:-4],
    ]];

    MSRefreshToolbarUI();
}

// ----------------------------------------------------------------------------
// Logos Hooks: SBHIconManager
// ----------------------------------------------------------------------------
%hook SBHIconManager
- (id)init {
    id manager = %orig;
    if (manager) {
        gIconManager = manager;
    }
    return manager;
}

- (void)setEditing:(BOOL)editing withFeedbackBehavior:(id)feedbackBehavior {
    %orig;

    if (editing && !gSelectionMode) {
        gSelectionMode = YES;
        MSShowActionToolbar();
    } else if (!editing && gSelectionMode) {
        MSHideToolbarAndClear();
    }
}

- (void)iconViewWasTapped:(id)iconView {
    if (gSelectionMode && [self isEditing]) {
        id icon = nil;
        SEL iconSel = sel_registerName("icon");
        if ([iconView respondsToSelector:iconSel]) {
            icon = ((id (*)(id, SEL))objc_msgSend)(iconView, iconSel);
        }
        if (icon && MSIsDeletableIcon(icon)) {
            MSToggleIconSelection(icon, (UIView *)iconView);
            return;
        }
    }
    %orig;
}

- (void)iconViewWasTapped:(id)iconView modifierFlags:(long long)flags {
    if (gSelectionMode && [self isEditing]) {
        id icon = nil;
        SEL iconSel = sel_registerName("icon");
        if ([iconView respondsToSelector:iconSel]) {
            icon = ((id (*)(id, SEL))objc_msgSend)(iconView, iconSel);
        }
        if (icon && MSIsDeletableIcon(icon)) {
            MSToggleIconSelection(icon, (UIView *)iconView);
            return;
        }
    }
    %orig;
}

%new
- (void)ms_handleSelectAll:(UIButton *)sender {
    if (gSelectedIcons.count > 0) {
        [gSelectedIcons removeAllObjects];
        MSRefreshToolbarUI();
        return;
    }

    if (!gSelectedIcons) {
        gSelectedIcons = [NSMutableSet new];
    }

    NSArray *icons = MSGetAllApplicationIcons(self);
    for (id icon in icons) {
        if (MSIsDeletableIcon(icon)) {
            [gSelectedIcons addObject:icon];
        }
    }

    MSRefreshToolbarUI();
}

%new
- (void)ms_handleDelete:(UIButton *)sender {
    if (gSelectedIcons.count == 0) return;
    NSUInteger count = gSelectedIcons.count;

    // Inline safety confirmation: avoids UIAlertController block PAC trap
    if ([sender.titleLabel.text isEqualToString:MSRuntimeString("Delete")]) {
        char confirmTitle[64];
        snprintf(confirmTitle, sizeof(confirmTitle), "Confirm (%lu)", (unsigned long)count);
        [sender setTitle:MSRuntimeString(confirmTitle) forState:UIControlStateNormal];
        [sender setTitleColor:UIColor.systemOrangeColor forState:UIControlStateNormal];
        if (gCountLabel) {
            char status[64];
            snprintf(status, sizeof(status), "Delete %lu?", (unsigned long)count);
            gCountLabel.text = MSRuntimeString(status);
        }
        return;
    }

    // Second tap: triggers batch deletion of selected apps
    NSArray *iconsToDelete = [gSelectedIcons allObjects];
    [gToolbar removeFromSuperview];
    gToolbar = nil;
    [gSelectedIcons removeAllObjects];
    MSStartBatchUninstall(iconsToDelete);
}

%new
- (void)ms_processUninstallTimer:(NSTimer *)timer {
    MSProcessNextUninstall();
}

%new
- (void)ms_handleDone:(UIButton *)sender {
    MSHideToolbarAndClear();
    if ([self respondsToSelector:@selector(setEditing:withFeedbackBehavior:)]) {
        [self setEditing:NO withFeedbackBehavior:nil];
    }
}
%end

// ----------------------------------------------------------------------------
// Logos Hooks: SBIconView (Touch Interception & AutoLayout Sync)
// ----------------------------------------------------------------------------
%hook SBIconView
- (void)tapGestureDidChange:(id)gesture {
    if (gSelectionMode) {
        SEL stateSel = sel_registerName("state");
        NSInteger state = 0;
        if ([gesture respondsToSelector:stateSel]) {
            state = ((NSInteger (*)(id, SEL))objc_msgSend)(gesture, stateSel);
        }
        if (state == UIGestureRecognizerStateEnded || state == 3) {
            id icon = nil;
            SEL iconSel = sel_registerName("icon");
            if ([self respondsToSelector:iconSel]) {
                icon = ((id (*)(id, SEL))objc_msgSend)(self, iconSel);
            }
            if (icon && MSIsDeletableIcon(icon)) {
                MSToggleIconSelection(icon, self);
                return;
            }
        }
    }
    %orig;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (gSelectionMode) {
        id icon = nil;
        SEL iconSel = sel_registerName("icon");
        if ([self respondsToSelector:iconSel]) {
            icon = ((id (*)(id, SEL))objc_msgSend)(self, iconSel);
        }
        if (icon && MSIsDeletableIcon(icon)) {
            MSToggleIconSelection(icon, self);
            return;
        }
    }
    %orig;
}

- (void)layoutSubviews {
    %orig;
    if (gSelectionMode && gSelectedIcons.count > 0) {
        id icon = nil;
        SEL iconSel = sel_registerName("icon");
        if ([self respondsToSelector:iconSel]) {
            icon = ((id (*)(id, SEL))objc_msgSend)(self, iconSel);
        }
        BOOL isSelected = (icon && [gSelectedIcons containsObject:icon]);
        MSSetIconViewBorder(self, isSelected);
    } else {
        MSSetIconViewBorder(self, NO);
    }
}

- (void)prepareForReuse {
    %orig;
    MSSetIconViewBorder(self, NO);
}
%end