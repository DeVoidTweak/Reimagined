# MultiSelectHome (iOS 16.1.1 Dopamine Rootless)
Target: SpringBoard (iPhone 14 Pro Max / iphone15,3, A16 PAC arm64e)
SDK: iPhoneOS 16.5 | Toolchain: Theos Manager on-device

## Why SpringBoard Froze on Black Screen (And How It Is Fixed):
1. PAC Block Traps: On-device Clang on iOS 16 arm64e fails to emit valid PAC signatures for UIAction block literals (^). This caused dyld to silently abort before SpringBoard launched.
   FIX: All buttons now use standard Objective-C target-action (@selector) with ZERO blocks!
2. Objective-C Constant Strings: On-device Clang on Dopamine corrupts __CFConstantString relocations for @"..." strings.
   FIX: 100% of runtime strings use MSRuntimeString("...") (just like your working 1.0.14 build).
3. Missing Filter Plist: If Theos failed to package MultiSelectHome.plist, the tweak was injected into backboardd (the display server), causing the black screen.
   FIX: MultiSelectHome.plist AND Filter.plist are provided.

## Recommended Stepping Procedure:
Step 1: Test "Tweak.xm (v1.0.15 Step)". Compile and install it. Respring.
        Enter jiggle mode: confirm the blur bar appears with "MultiSelectHome 1.0.15".
        Tap "Test Tap": confirm the label turns green and increments.
        Tap "Done": confirms exit edit mode.
Step 2: Once Step 1 is confirmed safe, switch to "Tweak.xm (v1.1.0 Batch)".
        This adds "Select All" and "Delete Apps" with UIAlertController.

## Build Commands in Theos Manager / Terminal:
make clean package
dpkg -i packages/*.deb
sbreload
