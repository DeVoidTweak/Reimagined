// MultiSelectHome 1.0.14: UILabel runtime-string diagnostic build.
//
// This checks the selection lifecycle plus mounting a minimal toolbar on the
// SpringBoard root view. It does not intercept icons or call remove/uninstall.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SBHIconManager : NSObject
@property(nonatomic, readonly, getter=isEditing) BOOL editing;
- (void)setEditing:(BOOL)editing withFeedbackBehavior:(id)feedbackBehavior;
- (UIViewController *)rootViewController;
@end

static SBHIconManager *gIconManager;
static NSMutableSet *gSelectedIcons;
static BOOL gSelectionMode;
static UIVisualEffectView *gToolbar;

static NSString *MSRuntimeString(const char *value) {
    return [NSString stringWithUTF8String:value];
}

static void MSShowDiagnosticToolbar(void) {
    if (gToolbar ||
        ![gIconManager respondsToSelector:@selector(rootViewController)]) {
        return;
    }

    UIView *hostView = [gIconManager rootViewController].view;
    if (!hostView) return;

    gToolbar = [[UIVisualEffectView alloc] initWithEffect:
                [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark]];
    gToolbar.layer.cornerRadius = 18;
    gToolbar.clipsToBounds = YES;
    gToolbar.translatesAutoresizingMaskIntoConstraints = NO;
    [hostView addSubview:gToolbar];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.text = MSRuntimeString("MultiSelectHome diagnostic");
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    [gToolbar.contentView addSubview:label];

    [NSLayoutConstraint activateConstraints:@[
        [gToolbar.leadingAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.leadingAnchor constant:12],
        [gToolbar.trailingAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.trailingAnchor constant:-12],
        [gToolbar.bottomAnchor constraintEqualToAnchor:hostView.safeAreaLayoutGuide.bottomAnchor constant:-8],
        [gToolbar.heightAnchor constraintEqualToConstant:58],
        [label.centerXAnchor constraintEqualToAnchor:gToolbar.contentView.centerXAnchor],
        [label.centerYAnchor constraintEqualToAnchor:gToolbar.contentView.centerYAnchor],
    ]];
}

static void MSHideDiagnosticToolbar(void) {
    [gToolbar removeFromSuperview];
    gToolbar = nil;
}

%hook SBHIconManager
- (id)init {
    id manager = %orig;
    if (manager) {
        gIconManager = manager;
    }
    return manager;
}

- (void)setEditing:(BOOL)editing withFeedbackBehavior:(id)feedbackBehavior {
    %orig;

    if (editing && !gSelectionMode) {
        gSelectionMode = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (gSelectionMode) {
                MSShowDiagnosticToolbar();
            }
        });
    } else if (!editing && gSelectionMode) {
        gSelectionMode = NO;
        [gSelectedIcons removeAllObjects];
        MSHideDiagnosticToolbar();
    }
}
%end

%ctor {
    gSelectedIcons = [NSMutableSet new];
}
