// MultiSelectHome 1.0.3: load-only diagnostic build.
//
// This dylib is still filtered to SpringBoard and is packaged exactly like the
// production tweak, but it intentionally installs no hooks and performs no
// UIKit or SpringBoard work.

#import <Foundation/Foundation.h>

%ctor {
}
